// popup.js
document.addEventListener('DOMContentLoaded', () => {
    // Configurações padrão
    const defaultConfig = {
        nextQuestionDelay: 1500,
        alternativeDelay: 500,
        videoDelay: 1000,
        retryDelay: 2000,
        speedrunMode: true,
        debugMode: false,
        autoStart: true
    };

    let scriptStatus = {
        isRunning: false,
        questionsResolved: 0,
        videosWatched: 0,
        startTime: null
    };

    // Carrega configurações salvas
    chrome.storage.local.get(defaultConfig, (config) => {
        Object.keys(config).forEach(key => {
            const element = document.getElementById(key);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = config[key];
                } else {
                    element.value = config[key];
                }
            }
        });
        updateStatus();
    });

    // Atualiza status do script
    function updateStatus() {
        const statusElement = document.getElementById('scriptStatus');
        if (statusElement) {
            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                chrome.tabs.sendMessage(tabs[0].id, { type: 'getStatus' }, (response) => {
                    if (response) {
                        scriptStatus = response;
                        const runTime = scriptStatus.startTime ? 
                            Math.floor((Date.now() - scriptStatus.startTime) / 1000) : 0;
                        
                        statusElement.innerHTML = `
                            Status: ${scriptStatus.isRunning ? '🟢 Ativo' : '🔴 Parado'}<br>
                            Questões: ${scriptStatus.questionsResolved}<br>
                            Vídeos: ${scriptStatus.videosWatched}<br>
                            Tempo: ${Math.floor(runTime / 60)}m ${runTime % 60}s
                        `;
                    }
                });
            });
        }
    }

    // Salva configurações
    document.getElementById('saveConfig').addEventListener('click', () => {
        const config = {};
        document.querySelectorAll('[id]').forEach(element => {
            if (element.id !== 'saveConfig' && element.id !== 'status' && element.id !== 'scriptStatus') {
                config[element.id] = element.type === 'checkbox' ? element.checked : parseInt(element.value);
            }
        });

        chrome.storage.local.set(config, () => {
            const status = document.getElementById('status');
            status.innerHTML = '✅ Salvo!';
            setTimeout(() => status.innerHTML = '', 2000);

            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                chrome.tabs.sendMessage(tabs[0].id, {
                    type: 'configUpdate',
                    config: config
                });
            });
        });
    });

    // Toggle script
    document.getElementById('toggleScript')?.addEventListener('click', () => {
        scriptStatus.isRunning = !scriptStatus.isRunning;
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, {
                type: 'toggleScript',
                status: scriptStatus.isRunning
            });
        });
        updateStatus();
    });

    // Atualiza status a cada 1s
    setInterval(updateStatus, 1000);
});